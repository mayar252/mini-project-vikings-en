# Additional Challenge for the Nerds
#You can try to make your own tests for your code by creating another test file.
import unittest
from vikingsClasses import Saxon

class TestSaxon(unittest.TestCase):
    def setUp(self):
        self.saxon = Saxon(80, 40)  # Create a Saxon with 80 health and 40 strength

    def testSaxonAttributes(self):
        self.assertEqual(self.saxon.health, 80)
        self.assertEqual(self.saxon.strength, 40)

    def testReceiveDamage(self):
        result = self.saxon.receiveDamage(20)
        self.assertEqual(result, "A Saxon has received 20 points of damage")
        self.assertEqual(self.saxon.health, 60)

        result = self.saxon.receiveDamage(60)
        self.assertEqual(result, "A Saxon has died in combat")
        self.assertEqual(self.saxon.health, 0)

if __name__ == '__main__':
    unittest.main()