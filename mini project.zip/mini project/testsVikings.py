# Additional Challenge for the Nerds
#You can try to make your own tests for your code by creating another test file.
import unittest
from vikingsClasses import Viking

class TestViking(unittest.TestCase):
    def setUp(self):
        self.viking = Viking("Thor", 100, 60)  # Create a Viking named Thor

    def testVikingAttributes(self):
        self.assertEqual(self.viking.name, "Thor")
        self.assertEqual(self.viking.health, 100)
        self.assertEqual(self.viking.strength, 60)

    def testBattleCry(self):
        self.assertEqual(self.viking.battleCry(), "Odin Owns You All!")

    def testReceiveDamage(self):
        result = self.viking.receiveDamage(30)
        self.assertEqual(result, "Thor has received 30 points of damage")
        self.assertEqual(self.viking.health, 70)

        result = self.viking.receiveDamage(70)
        self.assertEqual(result, "Thor has died in act of combat")
        self.assertEqual(self.viking.health, 0)

if __name__ == '__main__':
    unittest.main()