# Additional Challenge for the Nerds
#You can try to make your own tests for your code by creating another test file.
import unittest
from vikingsClasses import War, Viking, Saxon

class TestWar(unittest.TestCase):
    def setUp(self):
        self.war = War()  # Create a new War instance
        self.viking = Viking("Thor", 100, 50)  # Create a Viking
        self.saxon = Saxon(80, 30)  # Create a Saxon

        # Add Vikings and Saxons
        self.war.addViking(self.viking)
        self.war.addSaxon(self.saxon)

    def testAddViking(self):
        self.war.addViking(Viking("Odin", 100, 50))
        self.assertEqual(len(self.war.vikingArmy), 2)

    def testAddSaxon(self):
        self.war.addSaxon(Saxon(80, 30))
        self.assertEqual(len(self.war.saxonArmy), 2)

    def testShowStatus(self):
        # Simulate a battle where the Saxon is defeated
        self.war.vikingAttack()  # Thor attacks Saxon
        self.war.vikingAttack()  # Thor attacks again, Saxon will die
        self.war.showStatus()  # This should now reflect that Vikings have won
        self.assertEqual(self.war.showStatus(), "Vikings have won the war of the century!")

if __name__ == '__main__':
    unittest.main()