
# BONUS PART
import random
from vikingsClasses import Viking, Saxon, War

# Function to create a team of Vikings or Saxons
def create_team(name_list, team_size, is_viking=True):
    team = []
    for _ in range(team_size):
        name = random.choice(name_list)
        strength = random.randint(20, 60)
        health = 100
        if is_viking:
            team.append(Viking(name, health, strength))
        else:
            team.append(Saxon(health, strength))
    return team

# Function to run the game
def run_game(viking_team, saxon_team):
    print("The Battle Begins!")
    great_war = War()

    # Add the teams to the war
    for viking in viking_team:
        great_war.addViking(viking)
    for saxon in saxon_team:
        great_war.addSaxon(saxon)

    round_number = 0

    # Battle loop
    while great_war.showStatus() == "Vikings and Saxons are still in the thick of battle.":
        great_war.vikingAttack()
        
        if great_war.saxonArmy:
            great_war.saxonAttack()

        print(f"Round: {round_number} // Viking army: {len(great_war.vikingArmy)} warriors, "
              f"Saxon army: {len(great_war.saxonArmy)} warriors")
        print(great_war.showStatus())
        
        round_number += 1

# Main function
if __name__ == "__main__":
    # List of names for Vikings and Saxons
    names = ["Alfred", "Beatrice", "Cecilia", "David", "Elena", 
             "Felix", "Gina", "Henry", "Isabella", "Jack"]

    # Create teams
    viking_team = create_team(names, 5, is_viking=True)
    saxon_team = create_team(names, 5, is_viking=False)

    # Run the game
    run_game(viking_team, saxon_team)