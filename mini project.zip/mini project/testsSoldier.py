# Additional Challenge for the Nerds
#You can try to make your own tests for your code by creating another test file.
import unittest
from vikingsClasses import Soldier

class TestSoldier(unittest.TestCase):
    def setUp(self):
        self.soldier = Soldier(100, 50)  # Create a Soldier with 100 health and 50 strength

    def testConstructorSignature(self):
        self.assertEqual(self.soldier.health, 100)
        self.assertEqual(self.soldier.strength, 50)

    def testAttackHasNoParams(self):
        self.assertEqual(self.soldier.attack(), 50)

    def testCanReceiveDamage(self):
        self.soldier.receiveDamage(30)
        self.assertEqual(self.soldier.health, 70)

    def testReceivesDamage(self):
        self.soldier.receiveDamage(50)
        self.assertEqual(self.soldier.health, 50)

    def testReceiveDamageReturnNone(self):
        result = self.soldier.receiveDamage(50)
        self.assertIsNone(result)

    def testHealth(self):
        self.assertEqual(self.soldier.health, 100)

if __name__ == '__main__':
    unittest.main()